import {
  startStreaming,
  stopSession,
  handleClick,
  handleScroll,
  handleKey,
} from "./playwrightService.js";

export async function handleWebSocket(ws) {
  console.log("🔗 WebSocket connected");

  ws.on("message", async msg => {
    try {
      const data = JSON.parse(msg);
      switch (data.type) {
        case "start":
          startStreaming(ws, data.url);
          break;
        case "stop":
          stopSession(ws);
          break;
        case "click":
          handleClick(ws, data.x, data.y, data.frontendSize);
          break;
        case "scroll":
          handleScroll(ws, data.deltaY);
          break;
        case "keypress":
          handleKey(ws, data.key);
          break;
      }
    } catch (err) {
      console.error("WS msg error:", err);
    }
  });

  ws.on("close", () => stopSession(ws));
}
