import AxeBuilder from "@axe-core/playwright";
import PDFDocument from "pdfkit";
import fs from "fs";

export async function runAccessibilityScan(page) {
  const results = await new AxeBuilder({ page }).analyze();
  return results;
}

export async function generateReportPDF(results, outPath = "accessibility-report.pdf") {
  const doc = new PDFDocument();
  doc.fontSize(18).text("Accessibility Report", { underline: true }).moveDown();

  doc.fontSize(12).text(`Violations found: ${results.violations.length}\n\n`);
  results.violations.forEach((v, i) => {
    doc.text(`${i + 1}. ${v.id}  [${v.impact}]`);
    doc.text(v.description);
    doc.text("Help: " + v.helpUrl);
    doc.moveDown();
  });

  doc.pipe(fs.createWriteStream(outPath));
  doc.end();
  return outPath;
}
