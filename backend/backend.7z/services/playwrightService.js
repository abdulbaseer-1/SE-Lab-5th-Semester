// // services/playwrightService.js
// import { chromium } from "playwright";

// let browser, page, streaming = false;

// /**
//  * Launch Playwright and open the given URL
//  */
// export async function startBrowser(url) {
//     console.log("inside start browser function  url: " + url);

//   if (browser) await stopBrowser();

//   browser = await chromium.launch({ headless: true });
//   page = await browser.newPage();

//   console.log("🌍 Navigating to:", url);
//   await page.goto(url, { waitUntil: "domcontentloaded" }); // <– This expects a valid URL

//   return page;
// }


// /**
//  * Start continuous screenshot streaming
//  */
// export async function startStreaming(ws, url) {
//   page = await startBrowser(url); // ✅ remove "const" here
//   streaming = true;

//   async function captureLoop() {
//     while (streaming && !ws.closed) {
//       try {
//         const screenshotBuffer = await page.screenshot();
//         const base64 = screenshotBuffer.toString("base64");

//         ws.send(JSON.stringify({ type: "frame", data: base64 }));
//         console.log("🖼️ Sent frame", base64.slice(0, 20));

//         await new Promise((r) => setTimeout(r, 200));
//       } catch (err) {
//         console.error("Screenshot error:", err);
//         break;
//       }
//     }
//   }

//   captureLoop();
// }


// /**
//  * Stop streaming and close browser
//  */
// export async function stopBrowser() {
//   streaming = false;
//   if (browser) {
//     await browser.close();
//     browser = null;
//   }
//   page = null; // ✅ reset page reference
// }


// /**
//  * Load a website once and return its HTML content
//  * Used by the HTTP route (/open-website)
//  */
// export async function loadWebsite(url) {
//   if (!url || !url.startsWith("http")) {
//     throw new Error("Invalid or missing URL");
//   }

//   console.log("🌍 Loading website via loadWebsite():", url);

//   const browser = await chromium.launch({ headless: true });
//   const page = await browser.newPage();
//   await page.goto(url, { waitUntil: "domcontentloaded" });

//   const html = await page.content(); // get full rendered HTML
//   await browser.close();

//   return html;
// }



// /**
//  * Handle click event (scaled)
//  */
// export async function handleClick(x, y, frontendSize) {
//   if (!page) return;

//   const viewport = page.viewportSize();
//   if (!viewport) return;

//   // Scale coordinates from frontend size to real viewport size
//   const scaleX = viewport.width / frontendSize.width;
//   const scaleY = viewport.height / frontendSize.height;

//   const actualX = x * scaleX;
//   const actualY = y * scaleY;

//   console.log(`🖱️ Click at scaled coords: (${actualX}, ${actualY})`);
//   await page.mouse.click(actualX, actualY);
// }

// /**
//  * Handle typing event
//  */
// export async function handleType(text) {
//   if (!page) return;
//   console.log(`⌨️ Typing: ${text}`);
//   await page.keyboard.type(text, { delay: 100 });
// }

// /**
//  * Handle scroll event
//  */
// export async function handleScroll(deltaY) {
//   if (!page) return;
//   console.log(`🖱️ Scrolling: ${deltaY}`);
//   await page.mouse.wheel(0, deltaY);
// }




import { chromium } from "playwright";

const sessions = new Map(); // Map<ws, { browser, page, streaming }>

export async function startSession(ws, url) {
  if (sessions.has(ws)) await stopSession(ws);

  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 15000 });

  const session = { browser, page, streaming: false };
  sessions.set(ws, session);
  return session;
}

export async function stopSession(ws) {
  const session = sessions.get(ws);
  if (!session) return;
  session.streaming = false;
  await session.browser.close().catch(() => {});
  sessions.delete(ws);
}

/** Stream compressed JPEG frames */
export async function startStreaming(ws, url) {
  const session = await startSession(ws, url);
  const { page } = session;
  session.streaming = true;

  while (session.streaming && ws.readyState === ws.OPEN) {
    try {
      const buf = await page.screenshot({ type: "jpeg", quality: 60 });
      ws.send(JSON.stringify({ type: "frame", data: buf.toString("base64") }));

      // Optionally send DOM occasionally (every ~1s)
      if (!session.lastDomTime || Date.now() - session.lastDomTime > 1000) {
        const html = await page.content();
        ws.send(JSON.stringify({ type: "dom", html }));
        session.lastDomTime = Date.now();
      }

      await new Promise(r => setTimeout(r, 150)); // ~6–7 fps
    } catch (e) {
      console.error("stream error:", e.message);
      break;
    }
  }
}

/** Input events */
export async function handleClick(ws, x, y, frontendSize) {
  const session = sessions.get(ws);
  if (!session) return;
  const vp = session.page.viewportSize();
  const scaleX = vp.width / frontendSize.width;
  const scaleY = vp.height / frontendSize.height;
  await session.page.mouse.click(x * scaleX, y * scaleY);
}

export async function handleScroll(ws, deltaY) {
  const s = sessions.get(ws);
  if (s) await s.page.mouse.wheel(0, deltaY);
}

export async function handleKey(ws, key) {
  const s = sessions.get(ws);
  if (s) await s.page.keyboard.type(key, { delay: 50 });
}

export async function getPage(ws) {
  return sessions.get(ws)?.page;
}
