// import { loadWebsite } from '../services/playwrightService.js';

// export async function openWebsite(req, res) {
//   const { url } = req.query;
//   const html = await loadWebsite(url);
//   res.send(html);
// }

import { loadWebsite } from "../services/playwrightService.js";
import { runAccessibilityScan, generateReportPDF } from "../services/AccessibilityService.js";
import { chromium } from "playwright";

export async function openWebsite(req, res) {
  try {
    const { url } = req.query;
    const html = await loadWebsite(url);
    res.send(html);
  } catch (e) {
    res.status(400).send(e.message);
  }
}

export async function scanAccessibility(req, res) {
  try {
    const { url } = req.query;
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 15000 });

    const results = await runAccessibilityScan(page);
    const path = await generateReportPDF(results, "report.pdf");
    await browser.close();

    res.download(path);
  } catch (e) {
    console.error(e);
    res.status(500).send("Scan failed: " + e.message);
  }
}
