// import dotenv from "dotenv";
// import app from "./app.js";

// dotenv.config();

// //start the server
// const PORT = process.env.PORT || 5000;
// const server = app.listen(PORT, () => {
//     console.log(`🚀 Server running on http://localhost:${PORT}`);
//     console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
// });


// // Graceful Shutdown
// const shutDown = async () => {
//     console.log('📴 Shutting down gracefully...');
//     try {
//         // Close any resources like database connections here
//         console.log('✅ Closed resources');
//     } catch (err) {
//         console.error('❌ Error during shutdown:', err);
//     }
//     server.close(() => {
//         console.log('✅ Closed HTTP server');
//         process.exit(0);
//     });
//     setTimeout(() => {
//         console.error('❌ Forcefully shutting down');
//         process.exit(1);
//     }, 10000);
// };

// process.on('SIGTERM', shutDown);
// process.on('SIGINT', shutDown);




// /*
// err.stack :
//     Every JavaScript Error object has a property called .stack.

//     .stack contains a string representation of the error, including:

//     The error name (e.g., TypeError, ReferenceError)

//     The error message

//     A stack trace (the list of function calls that led to the error, with filenames and line numbers)




//     Express uses a library called path-to-regexp internally to convert route paths like /user/:id into regular expressions.
// */
// /*
// But /"/.* or /.*\/"is not a valid Express path pattern — it confuses path-to-regexp, which expects parameter names or literal segments (not regex syntax directly).
// Option 1: Catch-all 404 route (recommended)

// Replace your 404 middleware line:

// app.use('/.*\/', (req, res) => {


// with this simpler one:

// app.use('*', (req, res) => {
//     res.status(404).json({ error: "page not found" });
// });


// ✅ This catches all unmatched routes and responds with 404.

// Option 2: Use a regular expression explicitly

// If you specifically want to use regex for matching (not necessary here, but allowed):

// app.use(/.*\/, (req, res) => {
//     res.status(404).json({ error: "page not found" });
// });


// ✅ This version uses a real JavaScript RegExp, not a string pattern — and it’s supported.
// */



// index.js
import dotenv from "dotenv";
import { server } from "./server.js";

dotenv.config();

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
