// // server.js
// import express from "express";
// import { WebSocketServer } from "ws";
// import http from "http";
// import {
//   startStreaming,
//   stopBrowser,
//   handleClick,
//   handleScroll,
//   handleType
// } from "./services/playwrightService.js";

// const app = express();
// const server = http.createServer(app);
// const wss = new WebSocketServer({ server });

// app.get("/", (req, res) => {
//   res.send("Playwright Stream Server Running ✅");
// });

// wss.on("connection", (ws) => {
//   console.log("🔌 WebSocket connected");

//   ws.on("message", async (msg) => {
//     try {
//       const data = JSON.parse(msg);

//       switch (data.type) {
//         case "start":
//           console.log("▶️ Starting stream for:", data.url);
//           await startStreaming(ws, data.url);
//           break;

//         case "stop":
//           console.log("⏹️ Stopping stream");
//           await stopBrowser();
//           break;

//         case "click":
//           console.log(`🖱️ Click event at (${data.x}, ${data.y})`);
//           await handleClick(data.x, data.y, data.frontendSize);
//           break;

//         case "scroll":
//           console.log(`🧭 Scroll event: ${data.deltaY}`);
//           await handleScroll(data.deltaY);
//           break;

//         case "type":
//           console.log(`⌨️ Typing event: ${data.text}`);
//           await handleType(data.text);
//           break;

//         default:
//           console.log("❓ Unknown event type:", data.type);
//       }
//     } catch (err) {
//       console.error("WS error:", err);
//     }
//   });

//   ws.on("close", async () => {
//     console.log("🔌 WebSocket disconnected");
//     await stopBrowser();
//   });
// });

// export { server };




// server.js
import express from "express";
import { WebSocketServer } from "ws";
import http from "http";
import {
  startStreaming,
  stopSession,
  handleClick,
  handleScroll,
  handleKey
} from "./services/playwrightService.js";

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.get("/", (req, res) => {
  res.send("✅ Playwright Stream Server Running");
});

wss.on("connection", (ws) => {
  console.log("🔌 WebSocket connected");

  ws.on("message", async (msg) => {
    try {
      const data = JSON.parse(msg);

      switch (data.type) {
        case "start":
          console.log("▶️ Starting stream for:", data.url);
          startStreaming(ws, data.url);
          break;

        case "stop":
          console.log("⏹️ Stopping session");
          await stopSession(ws);
          break;

        case "click":
          console.log(`🖱️ Click event at (${data.x}, ${data.y})`);
          await handleClick(ws, data.x, data.y, data.frontendSize);
          break;

        case "scroll":
          console.log(`🧭 Scroll event: ${data.deltaY}`);
          await handleScroll(ws, data.deltaY);
          break;

        case "keypress":
          console.log(`⌨️ Key press: ${data.key}`);
          await handleKey(ws, data.key);
          break;

        default:
          console.warn("❓ Unknown message type:", data.type);
      }
    } catch (err) {
      console.error("❌ WebSocket message error:", err.message);
    }
  });

  ws.on("close", async () => {
    console.log("🔌 WebSocket disconnected");
    await stopSession(ws);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
