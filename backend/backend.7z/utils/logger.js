import { chromium } from 'playwright';

export async function loadWebsite(url) {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: 'domcontentloaded' });

  // Example: get HTML snapshot
  const content = await page.content();

  // Optional: take screenshot
  await page.screenshot({ path: 'page.png', fullPage: true });

  await browser.close();
  return content;
}
