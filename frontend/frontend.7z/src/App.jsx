import LiveViewer from "./components/LiveViewer.jsx";
function App() {
  return <LiveViewer />;
}
export default App;
