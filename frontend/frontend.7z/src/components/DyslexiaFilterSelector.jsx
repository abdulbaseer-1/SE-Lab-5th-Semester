// import React, { useEffect, useRef } from "react";

// export function DyslexiaFilterSelector({ enabled, intensity = 1, children }) {
//   const wrapperRef = useRef(null);

//   useEffect(() => {
//     if (!enabled || !wrapperRef.current) return;

//     const root = wrapperRef.current;

//     const processTextNode = (node) => {
//       const text = node.textContent;
//       if (!text.trim()) return;

//       const fragment = document.createDocumentFragment();

//       for (let ch of text) {
//         const span = document.createElement("span");
//         span.textContent = ch;

//         // --- Letter transform intensity ---
//         const rotate = (Math.random() - 0.5) * (intensity * 2);
//         const jitterX = (Math.random() - 0.5) * (intensity * 0.6);
//         const jitterY = (Math.random() - 0.5) * (intensity * 0.6);
//         const spacing = (Math.random() - 0.5) * (intensity * 0.06);

//         span.style.display = "inline-block";
//         span.style.transform = `translate(${jitterX}px, ${jitterY}px)
//                                 rotate(${rotate}deg)`;
//         span.style.letterSpacing = `${spacing}em`;

//         fragment.appendChild(span);
//       }

//       node.replaceWith(fragment);
//     };

//     const walk = (el) => {
//       for (let node of [...el.childNodes]) {
//         if (node.nodeType === Node.TEXT_NODE) {
//           processTextNode(node);
//         } else if (node.childNodes?.length) {
//           walk(node);
//         }
//       }
//     };

//     walk(root);

//     return () => {
//       root.innerHTML = "";
//       root.appendChild(children);
//     };
//   }, [enabled, intensity, children]);

//   if (!enabled) return <>{children}</>;

//   return <span ref={wrapperRef}>{children}</span>;
// }

import React, { useEffect, useRef } from "react";

export function DyslexiaFilterSelector({ enabled, intensity = 1, children }) {
  const wrapperRef = useRef(null);

  useEffect(() => {
    if (!enabled || !wrapperRef.current) return;

    const root = wrapperRef.current;

    // Helper: only transform pure text nodes
    const isSafeElement = (node) => {
      if (node.nodeType === Node.TEXT_NODE) return true;
      if (node.nodeType !== Node.ELEMENT_NODE) return false;

      // ❌ DO NOT touch these
      const forbidden = ["IMG", "VIDEO", "CANVAS", "SVG"];
      if (forbidden.includes(node.tagName)) return false;

      return true;
    };

    const processTextNode = (node) => {
      const text = node.textContent;
      if (!text.trim()) return;

      const fragment = document.createDocumentFragment();

      for (let ch of text) {
        const span = document.createElement("span");
        span.textContent = ch;

        const rotate = (Math.random() - 0.5) * (intensity * 2);
        const jitterX = (Math.random() - 0.5) * (intensity * 0.6);
        const jitterY = (Math.random() - 0.5) * (intensity * 0.6);
        const spacing = (Math.random() - 0.5) * (intensity * 0.06);

        span.style.display = "inline-block";
        span.style.transform = `translate(${jitterX}px, ${jitterY}px) rotate(${rotate}deg)`;
        span.style.letterSpacing = `${spacing}em`;

        fragment.appendChild(span);
      }

      node.replaceWith(fragment);
    };

    const walk = (el) => {
      for (let node of [...el.childNodes]) {
        if (!isSafeElement(node)) continue; // <img>, skip it entirely

        if (node.nodeType === Node.TEXT_NODE) {
          processTextNode(node);
        } else if (node.childNodes?.length) {
          walk(node);
        }
      }
    };

    walk(root);

    // Cleanup: restore original children
    return () => {
      if (!wrapperRef.current) return;
      wrapperRef.current.innerHTML = "";
    };
  }, [enabled, intensity, children]);

  if (!enabled) return <>{children}</>;

  return <span ref={wrapperRef}>{children}</span>;
}
