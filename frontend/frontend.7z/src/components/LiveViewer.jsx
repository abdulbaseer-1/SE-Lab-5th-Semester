import { useEffect, useRef, useState } from "react";
import useJitterCursor from "./useJitterCursor";
import {ColourBlindFilterSelector} from "./colorFilters";
import { LowVisionFilterSelector} from "./LowVision";
import { DyslexiaFilterSelector } from "./DyslexiaFilterSelector";

export default function LiveViewer() {
  const [image, setImage] = useState(null);
  const [url, setUrl] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [loading, setLoading] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [jitterEnabled, setJitterEnabled] = useState(false);
  const [jitterIntensity, setJitterIntensity] = useState(2);
  const [colourBlindeness, setColourBlindness] = useState("none");
  const [lowVision, setLowVision] = useState(false);
  const [lowVisionIntensity, setLowVisionIntensity] = useState(2);
  const [dyslexiaEnabled, setDyslexiaEnabled] = useState(false)
  const [dyslexiaIntensity, setDyslexiaIntensity] = useState(0)

  const wsRef = useRef(null);
  const frameRef = useRef(null);
  const frameBuffer = useRef([]);

  // Attach jittery cursor to streamed frame
  useJitterCursor(jitterEnabled, jitterIntensity, frameRef);

  // Connect and start streaming
  const startStream = () => {
    if (!url.trim()) return alert("Please enter a valid URL.");
    if (wsRef.current) wsRef.current.close();

    setLoading(true);
    wsRef.current = new WebSocket("ws://localhost:3000");

    wsRef.current.onopen = () => {
      console.log("✅ Connected to backend");
      wsRef.current.send(JSON.stringify({ type: "start", url }));
      setIsStreaming(true);
      setLoading(false);
    };

    wsRef.current.onmessage = (msg) => {
      const data = JSON.parse(msg.data);
      switch (data.type) {
        case "frame":
          frameBuffer.current.push(`data:image/png;base64,${data.data}`);
          break;
        case "scan_result":
          setScanResult(data.result);
          break;
        case "error":
          alert(data.message || "Error from backend");
          stopStream();
          break;
        case "dom_update":
          console.log("DOM Update received");
          break;
        default:
          console.warn("Unknown message:", data);
      }
    };

    wsRef.current.onclose = () => {
      console.log("❌ Connection closed");
      setIsStreaming(false);
      setLoading(false);
    };
  };

  // Smooth rendering loop
  useEffect(() => {
    const interval = setInterval(() => {
      if (frameBuffer.current.length > 0) {
        setImage(frameBuffer.current.shift());
      }
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const stopStream = () => {
    if (wsRef.current) {
      wsRef.current.send(JSON.stringify({ type: "stop" }));
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsStreaming(false);
    frameBuffer.current = [];
  };

  const requestScan = () => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN)
      return alert("Stream not active.");
    wsRef.current.send(JSON.stringify({ type: "scan_request" }));
  };

  const modifyDOM = (modifications) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN)
      return alert("Stream not active.");
    wsRef.current.send(
      JSON.stringify({ type: "modify_dom", payload: modifications })
    );
  };

  // Click handler
  useEffect(() => {
    const imgEl = frameRef.current;
    if (!imgEl) return;

    const handleClick = (e) => {
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
      const rect = imgEl.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      wsRef.current.send(
        JSON.stringify({
          type: "click",
          x,
          y,
          frontendSize: {
            width: imgEl.clientWidth,
            height: imgEl.clientHeight,
          },
        })
      );
    };

    imgEl.addEventListener("click", handleClick);
    return () => imgEl.removeEventListener("click", handleClick);
  }, [image]);

  // Keyboard typing
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
      wsRef.current.send(JSON.stringify({ type: "keypress", key: e.key }));
    };
    window.addEventListener("keypress", handleKeyPress);
    return () => window.removeEventListener("keypress", handleKeyPress);
  }, []);

  // Cleanup
  useEffect(() => () => stopStream(), []);

  return (
    <div className="flex flex-col items-center p-8">
      <h2 className="text-2xl font-bold mb-4">Web Accessibility Simulator</h2>

      {/* URL input */}
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter website URL (e.g. https://example.com)"
          className="w-[400px] p-2 border rounded"
        />
        {!isStreaming ? (
          <button
            onClick={startStream}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            disabled={loading}
          >
            {loading ? "Connecting..." : "Start"}
          </button>
        ) : (
          <button
            onClick={stopStream}
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
          >
            Stop
          </button>
        )}
      </div>

      {/* Jitter controls */}
      {isStreaming && (
        <div className="flex flex-col items-start mb-4 p-3 border rounded bg-gray-50">
          <label className="flex items-center gap-2 mb-2">
            <input
              type="checkbox"
              checked={jitterEnabled}
              onChange={(e) => setJitterEnabled(e.target.checked)}
            />
            Enable Hand Tremor Simulation
          </label>
          <label className="flex items-center gap-2">
            Jitter Intensity:
            <input
              type="range"
              min="0"
              max="10"
              value={jitterIntensity}
              onChange={(e) => setJitterIntensity(Number(e.target.value))}
            />
            <span className="text-sm text-gray-700">{jitterIntensity}px</span>
          </label>
        </div>
      )}

      {/* colorBlindness Dropdown */}
      {isStreaming && (
        <div className="colorBlindness mb-4 p-3 border rounded bg-gray-50">
          <label htmlFor="colourBlindTypes" className="mr-2">Color Blindness Simulation:</label>

          <select
            id="colourBlindTypes"
            value={colourBlindeness}
            onChange={(e) => setColourBlindness(e.target.value)}
            className="p-2 border rounded"
          >
            <option value="none">None</option>
            <option value="protanopia">Protanopia</option>
            <option value="deuteranopia">Deuteranopia</option>
            <option value="tritanopia">Tritanopia</option>
            <option value="acromatopsia">Acromatopsia</option>
          </select>
        </div>
      )}

      {/* low Vision */}
      {isStreaming && (
        <div className="Low Vision">
          <label className="LowVisio">
            LowVision?
            <input
              type="checkbox"
              checked={lowVision}
              onChange={(e) => setLowVision(e.target.checked)}
            />
            </label>

            <label className="Low Vision Intensity">
            Low Vision Intensity:
            <input
              type="range"
              min="0"
              max="7"
              step="0.1"
              value={lowVisionIntensity}
              onChange={(e) => setLowVisionIntensity(Number(e.target.value))}
            />
            <span>{lowVisionIntensity}px</span>
          </label>
        </div>
      )}

      {isStreaming && (
        <>
          <label className="Dyslexia-checkbox">
            Dyslexia: 
            <input 
              type="checkbox"
              name="DyslexiaEnabled" 
              id="DE"
              value={dyslexiaEnabled}
              onChange={(e) => setDyslexiaEnabled(e.target.checked)}
            />
          </label>

          <label className="Dyslexia-range">
            Dyslexia Severity:
            <input 
              type="range"
              min="0"
              max="10"
              step="0.1"
              value={dyslexiaIntensity}
              onChange={(e) => setDyslexiaIntensity(Number(e.target.value))}
            />
          </label>
        </>
      )}

      {/* Scan and DOM controls */}
      {isStreaming && (
        <div className="flex gap-2 mb-4">
          <button
            onClick={requestScan}
            className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
          >
            Run Accessibility Scan
          </button>
          <button
            onClick={() =>
              modifyDOM({ highlightHeadings: true, enlargeButtons: true })
            }
            className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
          >
            Apply DOM Fix
          </button>
        </div>
      )}

      {/* Live stream display *   ERROR  */ } 
      {image ? (
        <DyslexiaFilterSelector enabled={dyslexiaEnabled} intensity={dyslexiaIntensity}>
          <ColourBlindFilterSelector type={colourBlindeness}>
            <LowVisionFilterSelector enabled={lowVision} lowVisionIntensity={lowVisionIntensity}>
              <img
                ref={frameRef}  // attach ref only here
                src={image}
                alt="Live Website Stream"
                className="w-[90%] rounded shadow cursor-crosshair"
              />
            </LowVisionFilterSelector>
          </ColourBlindFilterSelector>
        </DyslexiaFilterSelector>
        // <ColourBlindFilterSelector type={colourBlindness}>
        //   <LowVisionFilterSelector enabled={lowVision} intensity={lowVisionIntensity}>
        //     <DyslexiaFilterSelector enabled={dyslexiaEnabled} intensity={dyslexiaIntensity}>
        //       <img
        //         src={image}
        //         ref={frameRef}
        //         className="w-[90%] rounded shadow"
        //         alt="live stream"
        //       />
        //     </DyslexiaFilterSelector>
        //   </LowVisionFilterSelector>
        // </ColourBlindFilterSelector>

      ) : (
        <p className="text-gray-500">
          {isStreaming
            ? "Loading live stream..."
            : "Enter a URL and click Start to begin streaming."}
        </p>
      )}

      {/* Scan results */}
      {scanResult && (
        <div className="mt-4 p-4 border rounded bg-gray-50 w-[80%] text-left">
          <h3 className="font-semibold mb-2">Accessibility Scan Result:</h3>
          <pre className="text-sm whitespace-pre-wrap">
            {JSON.stringify(scanResult, null, 2)}
          </pre>
          {scanResult.pdf && (
            <a
              href={`data:application/pdf;base64,${scanResult.pdf}`}
              download="accessibility_report.pdf"
              className="text-blue-600 underline mt-2 inline-block"
            >
              Download Report
            </a>
          )}
        </div>
      )}
    </div>
  );
}
