// colorFilters.jsx
import React from "react";

/**
 * SVG color-matrix filters for color blindness simulation.
 * Each FilterDefs renders SVG <filter> with a unique ID.
 *
 * Usage:
 * <Protanopia>
 *   <img src={frame} />
 * </Protanopia>
 *
 * The wrapper applies `filter: url(#protanopia)` to children (works for <img>, <canvas>, <div>).
 */

/* --- Utility wrapper --- */
function FilterWrap({ id, children, style, className }) {
  const wrapStyle = {
    filter: `url(#${id})`,
    WebkitFilter: `url(#${id})`,
    ...style,
  };
  return (
    <>
      <svg style={{ position: "absolute", width: 0, height: 0 }} aria-hidden>
        <defs>
          {/* defs are provided by caller-specific components below */}
        </defs>
      </svg>
      <div style={wrapStyle} className={className}>
        {children}
      </div>
    </>
  );
}

/* --- Protanopia --- */
export function Protanopia({ children, className, style, id = "protanopia-filter" }) {
  return (
    <>
      <svg style={{ position: "absolute", width: 0, height: 0 }} aria-hidden>
        <defs>
          <filter id={id}>
            <feColorMatrix
              type="matrix"
              values="
                0.567,0.433,0,0,0
                0.558,0.442,0,0,0
                0,0.242,0.758,0,0
                0,0,0,1,0
              "
            />
          </filter>
        </defs>
      </svg>
      <div style={{ filter: `url(#${id})` }} className={className}>
        {children}
      </div>
    </>
  );
}

/* --- Deuteranopia --- */
export function Deuteranopia({ children, className, style, id = "deuteranopia-filter" }) {
  return (
    <>
      <svg style={{ position: "absolute", width: 0, height: 0 }} aria-hidden>
        <defs>
          <filter id={id}>
            <feColorMatrix
              type="matrix"
              values="
                0.625,0.375,0,0,0
                0.7,0.3,0,0,0
                0,0.3,0.7,0,0
                0,0,0,1,0
              "
            />
          </filter>
        </defs>
      </svg>
      <div style={{ filter: `url(#${id})` }} className={className}>
        {children}
      </div>
    </>
  );
}

/* --- Tritanopia --- */
export function Tritanopia({ children, className, style, id = "tritanopia-filter" }) {
  return (
    <>
      <svg style={{ position: "absolute", width: 0, height: 0 }} aria-hidden>
        <defs>
          <filter id={id}>
            <feColorMatrix
              type="matrix"
              values="
                0.95,0.05,0,0,0
                0,0.433,0.567,0,0
                0,0.475,0.525,0,0
                0,0,0,1,0
              "
            />
          </filter>
        </defs>
      </svg>
      <div style={{ filter: `url(#${id})` }} className={className}>
        {children}
      </div>
    </>
  );
}

/* --- Achromatopsia (complete color blindness) --- */
export function Acromatopsia({ children, className, style, id = "acromatopsia-filter" }) {
  // Simpler: use grayscale color matrix
  return (
    <>
      <svg style={{ position: "absolute", width: 0, height: 0 }} aria-hidden>
        <defs>
          <filter id={id}>
            <feColorMatrix
              type="matrix"
              values="
                0.2126,0.7152,0.0722,0,0
                0.2126,0.7152,0.0722,0,0
                0.2126,0.7152,0.0722,0,0
                0,0,0,1,0
              "
            />
          </filter>
        </defs>
      </svg>
      <div style={{ filter: `url(#${id})` }} className={className}>
        {children}
      </div>
    </>
  );
}

export const ColourBlindFilterSelector = ({ type, children }) => {
  switch (type) {
    case "protanopia": return <Protanopia>{children}</Protanopia>;
    case "deuteranopia": return <Deuteranopia>{children}</Deuteranopia>;
    case "tritanopia": return <Tritanopia>{children}</Tritanopia>;
    case "acromatopsia": return <Acromatopsia>{children}</Acromatopsia>;
    default: return <>{children}</>; // just render children
  }
};