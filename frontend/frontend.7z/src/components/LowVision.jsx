// LowVision.jsx
import React, { useRef, useEffect } from "react";

/**
 * LowVision component (CSS) — simple blur + contrast + zoom.
 * Wrap the target element or image inside this component.
 *
 * <LowVision blur={4} contrast={0.9} zoom={1.1}>
 *   <img src={frame} />
 * </LowVision>
 */
/**
 * Maps low vision intensity (0-7) to CSS blur and brightness
 * 0   = perfect vision → blur 0px
 * 1-2 = mild → blur 1-2px
 * 3-5 = moderate → blur 3-5px
 * 6-7 = severe → blur 6-7px
 */
const mapIntensityToBlur = (intensity) => {
  // intensity: 0 (worst vision) → 7 (perfect vision)
  const maxBlur = 10; // maximum blur for lowest vision
  const minBlur = 0;  // no blur for perfect vision
  const clamped = Math.min(Math.max(intensity, 0), 7);
  
  // Invert scale: 0 -> maxBlur, 7 -> 0
  const blur = maxBlur * (1 - clamped / 7);
  return blur;
};

export const LowVision = ({
  children,
  blur = 4,
  contrast = 1,
  brightness = 1,
  zoom = 1.0,
  className,
  style,
}) => {
  const wrapStyle = {
    overflow: "hidden",
    display: "inline-block",
    transform: `scale(${zoom})`,
    transformOrigin: "center center",
  };

  const contentStyle = {
    filter: `blur(${blur}px) contrast(${contrast}) brightness(${brightness})`,
    display: "block",
  };

  return (
    <div style={{ ...wrapStyle, ...style }} className={className}>
      <div style={contentStyle}>{children}</div>
    </div>
  );
};

export const LowVisionFilterSelector = ({ lowVisionIntensity, enabled, children }) => {
  if (!enabled) return <>{children}</>;

  const blur = mapIntensityToBlur(lowVisionIntensity);
  const contrast = 0.9;
  const brightness = 0.95;

  return (
    <LowVision blur={blur} contrast={contrast} brightness={brightness} zoom={1}>
      {children}
    </LowVision>
  );
};